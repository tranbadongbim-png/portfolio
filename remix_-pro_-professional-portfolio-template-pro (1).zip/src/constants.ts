import { Github, Linkedin, Mail, ExternalLink, Box, Briefcase, User, GraduationCap, Trophy, HardHat, Layers, Wrench, PenTool } from 'lucide-react';

export const PERSONAL_INFO = {
  name: "Nguyen Van A",
  logoText: "DONG",
  role: "Senior BIM MEPF Engineer",
  headline: "Crafting digital experiences that matter.",
  avatar: "https://picsum.photos/seed/avatar/400/400",
  location: "Hanoi, Vietnam",
  email: "nva.bim@example.com",
  about: "Dedicated BIM MEPF Engineer with over 6 years of experience in Building Information Modeling and MEP coordination. Expert in Revit, Navisworks, and Dynamo for automating workflows. I specialize in complex clash detection, 4D/5D simulation, and producing high-quality shop drawings for large-scale commercial and industrial projects.",
  socials: [
    { name: "LinkedIn", url: "https://linkedin.com", icon: Linkedin },
    { name: "Email", url: "mailto:nva.bim@example.com", icon: Mail },
  ],
  navLinks: [
    { name: 'About', href: '#about' },
    { name: 'Projects', href: '#projects' },
    { name: 'Experience', href: '#experience' },
    { name: 'References', href: '#references' },
    { name: 'Contact', href: '#contact' },
  ]
};

export const SKILLS = [
  { category: "BIM Software", items: ["Revit (MEP)", "Navisworks Manage", "AutoCAD", "BIM 360 / ACC", "Dynamo"] },
  { category: "Engineering", items: ["HVAC Design", "Electrical Systems", "Plumbing & Fire Protection", "Clash Detection", "Shop Drawings"] },
  { category: "Standards & Tools", items: ["ISO 19650", "Enscape", "Dialux", "Bluebeam Revu", "Microsoft Project"] },
];

export const PROJECTS = [
  {
    title: "Grand Plaza Hotel & Residences",
    description: "Led the MEPF BIM coordination for a 45-story luxury hotel. Resolved over 2,500 clashes and managed the production of LOD 400 models.",
    tags: ["Revit", "Navisworks", "MEP Coordination"],
    link: "#",
    github: "#",
    image: "https://picsum.photos/seed/building/800/600"
  },
  {
    title: "High-Tech Electronics Factory",
    description: "Developed complex piping and HVAC BIM models for a cleanroom environment. Automated pipe support placement using Dynamo scripts.",
    tags: ["Dynamo", "Industrial", "Revit MEP"],
    link: "#",
    github: "#",
    image: "https://picsum.photos/seed/factory/800/600"
  },
  {
    title: "Central General Hospital",
    description: "Coordinated specialized medical gas systems and electrical containment in a highly constrained ceiling space using 3D BIM modeling.",
    tags: ["Healthcare", "BIM 360", "Clash Detection"],
    link: "#",
    github: "#",
    image: "https://picsum.photos/seed/hospital/800/600"
  }
];

export const EXPERIENCE = [
  {
    company: "Global Construction Group",
    role: "BIM Coordinator",
    period: "2021 - Present",
    description: "Managing BIM workflows for multi-disciplinary teams. Implementing ISO 19650 standards and conducting weekly coordination meetings."
  },
  {
    company: "MEP Design Consultants",
    role: "BIM MEP Engineer",
    period: "2018 - 2021",
    description: "Produced detailed 3D models and shop drawings for HVAC, Plumbing, and Electrical systems. Reduced rework by 25% through early clash detection."
  }
];

export const REFERENCES = [
  {
    name: "John Doe",
    position: "BIM Manager at Global Construction Group",
    email: "john.doe@example.com",
    phone: "+84 123 456 789"
  }
];

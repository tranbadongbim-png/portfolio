/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Github, 
  Linkedin, 
  Mail, 
  ExternalLink, 
  Layers, 
  Briefcase, 
  User, 
  GraduationCap, 
  ChevronRight,
  Menu,
  X,
  ArrowUpRight,
  HardHat,
  Box,
  Pencil,
  Plus,
  Trash2,
  Save,
  Settings,
  Phone,
  Users
} from 'lucide-react';
import { 
  PERSONAL_INFO as INITIAL_PERSONAL_INFO, 
  SKILLS as INITIAL_SKILLS, 
  PROJECTS as INITIAL_PROJECTS, 
  EXPERIENCE as INITIAL_EXPERIENCE,
  REFERENCES as INITIAL_REFERENCES
} from './constants';

// --- Components ---

const Modal = ({ isOpen, onClose, title, children }: { isOpen: boolean, onClose: () => void, title: string, children: React.ReactNode }) => {
  if (!isOpen) return null;
  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
      <motion.div 
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="bg-zinc-900 border border-white/10 rounded-3xl w-full max-w-2xl max-h-[90vh] overflow-y-auto p-8"
      >
        <div className="flex justify-between items-center mb-6">
          <h3 className="text-2xl font-bold text-white">{title}</h3>
          <button onClick={onClose} className="text-zinc-500 hover:text-white"><X size={24} /></button>
        </div>
        {children}
      </motion.div>
    </div>
  );
};

const Navbar = ({ 
  name, 
  isEditing, 
  onToggleEdit,
  data
}: { 
  name: string, 
  isEditing: boolean, 
  onToggleEdit: () => void,
  data: any
}) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 50);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = data.PERSONAL_INFO.navLinks || [
    { name: 'About', href: '#about' },
    { name: 'Projects', href: '#projects' },
    { name: 'Experience', href: '#experience' },
    { name: 'References', href: '#references' },
    { name: 'Contact', href: '#contact' },
  ];

  return (
    <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${isScrolled ? 'glass py-4' : 'bg-transparent py-6'}`}>
      <div className="max-w-7xl mx-auto px-6 flex justify-between items-center">
        <motion.a 
          href="#" 
          className="text-xl font-bold tracking-tighter text-white"
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
        >
          {data.PERSONAL_INFO.logoText || name.split(' ')[0].toUpperCase()}
          <span className="text-emerald-500">.</span>
        </motion.a>

        <div className="hidden md:flex items-center gap-8">
          {navLinks.map((link, i) => (
            <a key={link.name} href={link.href} className="text-sm font-medium text-zinc-400 hover:text-white transition-colors">
              {link.name}
            </a>
          ))}
          <button
            onClick={onToggleEdit}
            className={`flex items-center gap-2 px-4 py-2 rounded-full text-xs font-bold transition-all ${isEditing ? 'bg-emerald-500 text-zinc-900' : 'bg-white/10 text-white hover:bg-white/20'}`}
          >
            {isEditing ? <Save size={14} /> : <Settings size={14} />}
            {isEditing ? 'Finish Editing' : 'Edit Mode'}
          </button>
          {isEditing && (
            <button
              onClick={() => {
                if (confirm('Are you sure you want to reset all data to original defaults? All your current edits will be lost.')) {
                  localStorage.clear();
                  window.location.reload();
                }
              }}
              className="px-4 py-2 rounded-full text-xs font-bold bg-red-500/10 text-red-500 hover:bg-red-500/20 transition-all"
            >
              Reset All
            </button>
          )}
          {isEditing && (
            <button
              onClick={() => {
                navigator.clipboard.writeText(JSON.stringify(data, null, 2));
                alert('Configuration copied to clipboard! Paste it to the AI assistant to save it permanently.');
              }}
              className="px-4 py-2 rounded-full text-xs font-bold bg-emerald-500/10 text-emerald-400 hover:bg-emerald-500/20 transition-all"
            >
              Copy Config
            </button>
          )}
        </div>

        <button className="md:hidden text-white" onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}>
          {isMobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
      </div>
    </nav>
  );
};

const SectionHeading = ({ children, subtitle }: { children: React.ReactNode, subtitle?: string }) => (
  <div className="mb-12">
    <motion.h2 className="text-3xl md:text-4xl font-bold text-white mb-4 tracking-tight" initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}>
      {children}
    </motion.h2>
    {subtitle && (
      <motion.p className="text-zinc-500 max-w-2xl" initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: 0.1 }}>
        {subtitle}
      </motion.p>
    )}
  </div>
);

// --- Main App ---

export default function App() {
  const [isEditing, setIsEditing] = useState(false);
  
  const [personalInfo, setPersonalInfo] = useState(() => {
    const saved = localStorage.getItem('portfolio_personalInfo');
    if (saved) {
      const parsed = JSON.parse(saved);
      // Ensure new fields exist for backward compatibility with old localStorage data
      const merged = { ...INITIAL_PERSONAL_INFO, ...parsed };
      
      // Restore icons for social links from initial data
      merged.socials = merged.socials.map((s: any) => ({
        ...s,
        icon: INITIAL_PERSONAL_INFO.socials.find(is => is.name === s.name)?.icon || Mail
      }));
      return merged;
    }
    return INITIAL_PERSONAL_INFO;
  });
  const [skills, setSkills] = useState(() => {
    const saved = localStorage.getItem('portfolio_skills');
    return saved ? JSON.parse(saved) : INITIAL_SKILLS;
  });
  const [projects, setProjects] = useState(() => {
    const saved = localStorage.getItem('portfolio_projects');
    return saved ? JSON.parse(saved) : INITIAL_PROJECTS;
  });
  const [experience, setExperience] = useState(() => {
    const saved = localStorage.getItem('portfolio_experience');
    return saved ? JSON.parse(saved) : INITIAL_EXPERIENCE;
  });
  const [references, setReferences] = useState(() => {
    const saved = localStorage.getItem('portfolio_references');
    return saved ? JSON.parse(saved) : INITIAL_REFERENCES;
  });

  const [editModal, setEditModal] = useState<{ type: string, index?: number } | null>(null);

  // --- Persistence ---
  useEffect(() => {
    localStorage.setItem('portfolio_personalInfo', JSON.stringify(personalInfo));
  }, [personalInfo]);

  useEffect(() => {
    localStorage.setItem('portfolio_skills', JSON.stringify(skills));
  }, [skills]);

  useEffect(() => {
    localStorage.setItem('portfolio_projects', JSON.stringify(projects));
  }, [projects]);

  useEffect(() => {
    localStorage.setItem('portfolio_experience', JSON.stringify(experience));
  }, [experience]);

  useEffect(() => {
    localStorage.setItem('portfolio_references', JSON.stringify(references));
  }, [references]);

  // --- Handlers ---

  const handleUpdatePersonalInfo = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    setPersonalInfo({
      ...personalInfo,
      name: formData.get('name') as string,
      logoText: formData.get('logoText') as string,
      role: formData.get('role') as string,
      headline: formData.get('headline') as string,
      avatar: formData.get('avatar') as string,
      location: formData.get('location') as string,
      email: formData.get('email') as string,
      about: formData.get('about') as string,
      navLinks: (formData.get('navLinks') as string).split(',').map((name, i) => ({
        name: name.trim(),
        href: (personalInfo.navLinks || [])[i]?.href || `#${name.trim().toLowerCase()}`
      }))
    });
    setEditModal(null);
  };

  const handleUpdateProject = (e: React.FormEvent<HTMLFormElement>, index: number) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    const updatedProjects = [...projects];
    updatedProjects[index] = {
      ...updatedProjects[index],
      title: formData.get('title') as string,
      description: formData.get('description') as string,
      tags: (formData.get('tags') as string).split(',').map(t => t.trim()),
      image: formData.get('image') as string,
    };
    setProjects(updatedProjects);
    setEditModal(null);
  };

  const handleAddProject = () => {
    setProjects([...projects, {
      title: "New Project",
      description: "Project description goes here.",
      tags: ["Revit", "BIM"],
      link: "#",
      github: "#",
      image: "https://picsum.photos/seed/new/800/600"
    }]);
  };

  const handleRemoveProject = (index: number) => {
    setProjects(projects.filter((_, i) => i !== index));
  };

  const handleUpdateExperience = (e: React.FormEvent<HTMLFormElement>, index: number) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    const updatedExp = [...experience];
    updatedExp[index] = {
      ...updatedExp[index],
      company: formData.get('company') as string,
      role: formData.get('role') as string,
      period: formData.get('period') as string,
      description: formData.get('description') as string,
    };
    setExperience(updatedExp);
    setEditModal(null);
  };

  const handleAddExperience = () => {
    setExperience([...experience, {
      company: "New Company",
      role: "Your Role",
      period: "2023 - Present",
      description: "Describe your responsibilities."
    }]);
  };

  const handleRemoveExperience = (index: number) => {
    setExperience(experience.filter((_, i) => i !== index));
  };

  const handleUpdateSkillGroup = (e: React.FormEvent<HTMLFormElement>, index: number) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    const updatedSkills = [...skills];
    updatedSkills[index] = {
      ...updatedSkills[index],
      category: formData.get('category') as string,
      items: (formData.get('items') as string).split(',').map(s => s.trim()).filter(s => s !== ""),
    };
    setSkills(updatedSkills);
    setEditModal(null);
  };

  const handleAddSkillGroup = () => {
    setSkills([...skills, {
      category: "New Category",
      items: ["Skill 1", "Skill 2"]
    }]);
  };

  const handleRemoveSkillGroup = (index: number) => {
    setSkills(skills.filter((_, i) => i !== index));
  };

  const handleUpdateReference = (e: React.FormEvent<HTMLFormElement>, index: number) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    const updatedRefs = [...references];
    updatedRefs[index] = {
      ...updatedRefs[index],
      name: formData.get('name') as string,
      position: formData.get('position') as string,
      email: formData.get('email') as string,
      phone: formData.get('phone') as string,
    };
    setReferences(updatedRefs);
    setEditModal(null);
  };

  const handleAddReference = () => {
    setReferences([...references, {
      name: "New Reference",
      position: "Position",
      email: "email@example.com",
      phone: "+84 123 456 789"
    }]);
  };

  const handleRemoveReference = (index: number) => {
    setReferences(references.filter((_, i) => i !== index));
  };

  return (
    <div className="min-h-screen">
      <Navbar 
        name={personalInfo.name} 
        isEditing={isEditing} 
        onToggleEdit={() => setIsEditing(!isEditing)} 
        data={{
          PERSONAL_INFO: personalInfo,
          SKILLS: skills,
          PROJECTS: projects,
          EXPERIENCE: experience,
          REFERENCES: references
        }}
      />

      {/* Hero Section */}
      <section className="relative pt-32 pb-20 md:pt-48 md:pb-32 px-6 overflow-hidden">
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full max-w-7xl h-full pointer-events-none">
          <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-emerald-500/10 blur-[120px] rounded-full" />
          <div className="absolute bottom-[10%] right-[-10%] w-[30%] h-[30%] bg-cyan-500/10 blur-[100px] rounded-full" />
        </div>

        <div className="max-w-7xl mx-auto relative z-10">
          <motion.div initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }}>
            <div className="flex flex-col md:flex-row md:items-end gap-8 mb-12">
              <div className="relative group">
                <div className="w-32 h-32 md:w-48 md:h-48 rounded-2xl overflow-hidden border-2 border-white/10 bg-zinc-800">
                  <img 
                    src={personalInfo.avatar} 
                    alt={personalInfo.name} 
                    className="w-full h-full object-cover"
                    referrerPolicy="no-referrer"
                  />
                </div>
                {isEditing && (
                  <button 
                    onClick={() => setEditModal({ type: 'personal' })}
                    className="absolute -bottom-2 -right-2 p-2 bg-emerald-500 text-zinc-900 rounded-lg shadow-lg opacity-0 group-hover:opacity-100 transition-opacity"
                  >
                    <Pencil size={14} />
                  </button>
                )}
              </div>
              
              <div>
                <div className="flex items-center gap-4 mb-4">
                  <span className="inline-block px-4 py-1.5 rounded-full bg-emerald-500/10 text-emerald-400 text-xs font-bold uppercase tracking-widest border border-emerald-500/20">
                    Available for new opportunities
                  </span>
                </div>
                <h1 className="text-5xl md:text-8xl font-bold text-white tracking-tighter leading-[0.9]">
                  {personalInfo.headline}
                </h1>
              </div>
            </div>

            <p className="text-xl text-zinc-400 max-w-2xl mb-10 leading-relaxed">
              Hi, I'm <span className="text-white font-medium">{personalInfo.name}</span>. 
              {personalInfo.role} based in {personalInfo.location}. 
              I build high-performance applications with a focus on user experience.
            </p>

            <div className="flex flex-wrap gap-4">
              <a href="#projects" className="px-8 py-4 bg-white text-zinc-950 font-bold rounded-2xl flex items-center gap-2 hover:bg-zinc-200 transition-all group">
                View Projects
                <ChevronRight size={18} className="group-hover:translate-x-1 transition-transform" />
              </a>
              <div className="flex items-center gap-4 px-4">
                {personalInfo.socials.map((social) => (
                  <a key={social.name} href={social.url} className="p-3 text-zinc-400 hover:text-white hover:bg-white/5 rounded-xl transition-all">
                    <social.icon size={22} />
                  </a>
                ))}
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-24 px-6 bg-zinc-900/30">
        <div className="max-w-7xl mx-auto">
          <div className="grid md:grid-cols-2 gap-16 items-center">
            <motion.div initial={{ opacity: 0, x: -30 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }}>
              <div className="flex items-center gap-4 mb-4">
                <SectionHeading subtitle="A little bit about my background and what drives me.">
                  About Me
                </SectionHeading>
                {isEditing && (
                  <button onClick={() => setEditModal({ type: 'personal' })} className="p-2 bg-white/10 hover:bg-white/20 rounded-lg text-white mb-12">
                    <Pencil size={16} />
                  </button>
                )}
              </div>
              <div className="space-y-6 text-zinc-400 leading-relaxed text-lg">
                <p>{personalInfo.about}</p>
                <div className="grid grid-cols-2 gap-4 pt-4">
                  <div className="glass p-4 rounded-2xl">
                    <div className="text-emerald-400 mb-2"><Layers size={24} /></div>
                    <div className="text-white font-bold">6+ Years</div>
                    <div className="text-xs text-zinc-500 uppercase tracking-wider">Experience</div>
                  </div>
                  <div className="glass p-4 rounded-2xl">
                    <div className="text-cyan-400 mb-2"><Box size={24} /></div>
                    <div className="text-white font-bold">15+ Projects</div>
                    <div className="text-xs text-zinc-500 uppercase tracking-wider">BIM Models</div>
                  </div>
                </div>
              </div>
            </motion.div>

            <motion.div className="grid grid-cols-1 gap-6" initial={{ opacity: 0, x: 30 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }}>
              <div className="flex justify-between items-center mb-2">
                <h3 className="text-zinc-500 uppercase text-xs font-bold tracking-widest">Skills & Expertise</h3>
                {isEditing && (
                  <button onClick={handleAddSkillGroup} className="p-2 bg-emerald-500/10 text-emerald-400 hover:bg-emerald-500/20 rounded-lg transition-colors flex items-center gap-2 text-xs font-bold">
                    <Plus size={14} /> Add Group
                  </button>
                )}
              </div>
              {skills.map((skillGroup, i) => (
                <div key={i} className="glass p-6 rounded-3xl relative group/skill">
                  <div className="flex justify-between items-start mb-4">
                    <h3 className="text-white font-bold flex items-center gap-2">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                      {skillGroup.category}
                    </h3>
                    {isEditing && (
                      <div className="flex gap-2 opacity-0 group-hover/skill:opacity-100 transition-opacity">
                        <button onClick={() => setEditModal({ type: 'skill', index: i })} className="p-1.5 bg-white/10 hover:bg-white/20 rounded-lg text-white">
                          <Pencil size={14} />
                        </button>
                        <button onClick={() => handleRemoveSkillGroup(i)} className="p-1.5 bg-red-500/10 hover:bg-red-500/20 rounded-lg text-red-500">
                          <Trash2 size={14} />
                        </button>
                      </div>
                    )}
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {skillGroup.items.map((skill) => (
                      <span key={skill} className="px-3 py-1.5 bg-white/5 border border-white/10 rounded-lg text-sm text-zinc-300">
                        {skill}
                      </span>
                    ))}
                  </div>
                </div>
              ))}
            </motion.div>
          </div>
        </div>
      </section>

      {/* Projects Section */}
      <section id="projects" className="py-24 px-6">
        <div className="max-w-7xl mx-auto">
          <div className="flex justify-between items-end mb-12">
            <SectionHeading subtitle="A selection of my recent work, ranging from web apps to open source tools.">
              Featured Projects
            </SectionHeading>
            {isEditing && (
              <button onClick={handleAddProject} className="mb-12 px-4 py-2 bg-emerald-500 text-zinc-900 rounded-xl font-bold flex items-center gap-2 hover:bg-emerald-400 transition-all">
                <Plus size={18} /> Add Project
              </button>
            )}
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {projects.map((project, i) => (
              <motion.div
                key={i}
                className="group relative glass rounded-[2rem] overflow-hidden flex flex-col"
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
              >
                <div className="aspect-[4/3] overflow-hidden relative">
                  <img src={project.image} alt={project.title} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" referrerPolicy="no-referrer" />
                  <div className="absolute inset-0 bg-zinc-950/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-4">
                    {isEditing ? (
                      <>
                        <button onClick={() => setEditModal({ type: 'project', index: i })} className="p-3 bg-white text-zinc-950 rounded-full hover:scale-110 transition-transform">
                          <Pencil size={20} />
                        </button>
                        <button onClick={() => handleRemoveProject(i)} className="p-3 bg-red-500 text-white rounded-full hover:scale-110 transition-transform">
                          <Trash2 size={20} />
                        </button>
                      </>
                    ) : (
                      <>
                        <a href={project.link} className="p-3 bg-white text-zinc-950 rounded-full hover:scale-110 transition-transform"><ExternalLink size={20} /></a>
                        <a href={project.github} className="p-3 bg-zinc-900 text-white rounded-full hover:scale-110 transition-transform border border-white/10"><Github size={20} /></a>
                      </>
                    )}
                  </div>
                </div>
                <div className="p-8 flex-1 flex flex-col">
                  <div className="flex flex-wrap gap-2 mb-4">
                    {project.tags.map(tag => (
                      <span key={tag} className="text-[10px] uppercase font-bold tracking-widest text-emerald-400">{tag}</span>
                    ))}
                  </div>
                  <h3 className="text-xl font-bold text-white mb-3 group-hover:text-emerald-400 transition-colors">{project.title}</h3>
                  <p className="text-zinc-400 text-sm leading-relaxed mb-6 flex-1">{project.description}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Experience Section */}
      <section id="experience" className="py-24 px-6 bg-zinc-900/30">
        <div className="max-w-7xl mx-auto">
          <div className="flex justify-between items-end mb-12">
            <SectionHeading subtitle="My professional journey and the companies I've helped grow.">
              Work Experience
            </SectionHeading>
            {isEditing && (
              <button onClick={handleAddExperience} className="mb-12 px-4 py-2 bg-emerald-500 text-zinc-900 rounded-xl font-bold flex items-center gap-2 hover:bg-emerald-400 transition-all">
                <Plus size={18} /> Add Experience
              </button>
            )}
          </div>

          <div className="space-y-6">
            {experience.map((exp, i) => (
              <motion.div
                key={i}
                className="glass p-8 rounded-[2rem] flex flex-col md:flex-row md:items-center gap-8 group hover:border-emerald-500/30 transition-colors relative"
                initial={{ opacity: 0, x: -20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
              >
                <div className="md:w-48 shrink-0">
                  <div className="text-emerald-400 font-mono text-sm mb-1">{exp.period}</div>
                  <div className="text-white font-bold text-xl">{exp.company}</div>
                </div>
                <div className="flex-1">
                  <h4 className="text-lg font-bold text-zinc-200 mb-2">{exp.role}</h4>
                  <p className="text-zinc-400 leading-relaxed">{exp.description}</p>
                </div>
                <div className="flex items-center gap-2">
                  {isEditing ? (
                    <>
                      <button onClick={() => setEditModal({ type: 'experience', index: i })} className="p-3 bg-white/10 hover:bg-white/20 text-white rounded-xl transition-all">
                        <Pencil size={18} />
                      </button>
                      <button onClick={() => handleRemoveExperience(i)} className="p-3 bg-red-500/10 hover:bg-red-500/20 text-red-500 rounded-xl transition-all">
                        <Trash2 size={18} />
                      </button>
                    </>
                  ) : (
                    <div className="w-12 h-12 rounded-full border border-white/10 flex items-center justify-center text-zinc-500 group-hover:text-emerald-400 group-hover:border-emerald-500/30 transition-all">
                      <Briefcase size={20} />
                    </div>
                  )}
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* References Section */}
      <section id="references" className="py-24 px-6">
        <div className="max-w-7xl mx-auto">
          <div className="flex justify-between items-end mb-12">
            <SectionHeading subtitle="People who can vouch for my professional skills and character.">
              References
            </SectionHeading>
            {isEditing && (
              <button onClick={handleAddReference} className="mb-12 px-4 py-2 bg-emerald-500 text-zinc-900 rounded-xl font-bold flex items-center gap-2 hover:bg-emerald-400 transition-all">
                <Plus size={18} /> Add Reference
              </button>
            )}
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {references.map((ref, i) => (
              <motion.div
                key={i}
                className="glass p-8 rounded-[2rem] relative group/ref"
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
              >
                {isEditing && (
                  <div className="absolute top-6 right-6 flex gap-2 opacity-0 group-hover/ref:opacity-100 transition-opacity">
                    <button onClick={() => setEditModal({ type: 'reference', index: i })} className="p-2 bg-white/10 hover:bg-white/20 rounded-lg text-white">
                      <Pencil size={14} />
                    </button>
                    <button onClick={() => handleRemoveReference(i)} className="p-2 bg-red-500/10 hover:bg-red-500/20 rounded-lg text-red-500">
                      <Trash2 size={14} />
                    </button>
                  </div>
                )}
                <div className="w-12 h-12 bg-emerald-500/10 rounded-2xl flex items-center justify-center text-emerald-400 mb-6">
                  <Users size={24} />
                </div>
                <h3 className="text-xl font-bold text-white mb-1">{ref.name}</h3>
                <p className="text-emerald-400 text-sm font-medium mb-6">{ref.position}</p>
                
                <div className="space-y-3">
                  <div className="flex items-center gap-3 text-zinc-400 text-sm">
                    <Mail size={14} className="text-zinc-600" />
                    <a href={`mailto:${ref.email}`} className="hover:text-white transition-colors">{ref.email}</a>
                  </div>
                  <div className="flex items-center gap-3 text-zinc-400 text-sm">
                    <Phone size={14} className="text-zinc-600" />
                    <a href={`tel:${ref.phone}`} className="hover:text-white transition-colors">{ref.phone}</a>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-24 px-6 relative overflow-hidden">
        <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-full max-w-4xl h-64 bg-emerald-500/20 blur-[120px] rounded-full pointer-events-none" />
        
        <div className="max-w-3xl mx-auto text-center relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
          >
            <h2 className="text-4xl md:text-6xl font-bold text-white mb-8 tracking-tighter">
              Let's build something <br />
              <span className="text-gradient">extraordinary together.</span>
            </h2>
            <p className="text-xl text-zinc-400 mb-12">
              Currently open to freelance projects and full-time opportunities. 
              If you have a project in mind, let's talk.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <a 
                href={`mailto:${personalInfo.email}`}
                className="w-full sm:w-auto px-10 py-5 bg-emerald-500 hover:bg-emerald-400 text-zinc-950 font-bold rounded-2xl transition-all flex items-center justify-center gap-3"
              >
                <Mail size={20} />
                Send an Email
              </a>
              <a 
                href={personalInfo.socials.find(s => s.name === 'LinkedIn')?.url}
                className="w-full sm:w-auto px-10 py-5 glass hover:bg-white/10 text-white font-bold rounded-2xl transition-all flex items-center justify-center gap-3"
              >
                <Linkedin size={20} />
                LinkedIn
              </a>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Modals */}
      <Modal 
        isOpen={editModal?.type === 'personal'} 
        onClose={() => setEditModal(null)} 
        title="Edit Personal Info"
      >
        <form onSubmit={handleUpdatePersonalInfo} className="space-y-4">
          <div>
            <label className="block text-sm text-zinc-500 mb-2">Full Name</label>
            <input name="name" defaultValue={personalInfo.name} className="w-full bg-zinc-800 border border-white/10 rounded-xl p-3 text-white focus:outline-none focus:border-emerald-500" />
          </div>
          <div>
            <label className="block text-sm text-zinc-500 mb-2">Logo Text</label>
            <input name="logoText" defaultValue={personalInfo.logoText} className="w-full bg-zinc-800 border border-white/10 rounded-xl p-3 text-white focus:outline-none focus:border-emerald-500" />
          </div>
          <div>
            <label className="block text-sm text-zinc-500 mb-2">Navigation Links (comma separated)</label>
            <input name="navLinks" defaultValue={(personalInfo.navLinks || []).map((l: any) => l.name).join(', ')} className="w-full bg-zinc-800 border border-white/10 rounded-xl p-3 text-white focus:outline-none focus:border-emerald-500" />
          </div>
          <div>
            <label className="block text-sm text-zinc-500 mb-2">Role</label>
            <input name="role" defaultValue={personalInfo.role} className="w-full bg-zinc-800 border border-white/10 rounded-xl p-3 text-white focus:outline-none focus:border-emerald-500" />
          </div>
          <div>
            <label className="block text-sm text-zinc-500 mb-2">Headline</label>
            <input name="headline" defaultValue={personalInfo.headline} className="w-full bg-zinc-800 border border-white/10 rounded-xl p-3 text-white focus:outline-none focus:border-emerald-500" />
          </div>
          <div>
            <label className="block text-sm text-zinc-500 mb-2">Avatar URL</label>
            <input name="avatar" defaultValue={personalInfo.avatar} className="w-full bg-zinc-800 border border-white/10 rounded-xl p-3 text-white focus:outline-none focus:border-emerald-500" />
          </div>
          <div>
            <label className="block text-sm text-zinc-500 mb-2">Location</label>
            <input name="location" defaultValue={personalInfo.location} className="w-full bg-zinc-800 border border-white/10 rounded-xl p-3 text-white focus:outline-none focus:border-emerald-500" />
          </div>
          <div>
            <label className="block text-sm text-zinc-500 mb-2">Email</label>
            <input name="email" defaultValue={personalInfo.email} className="w-full bg-zinc-800 border border-white/10 rounded-xl p-3 text-white focus:outline-none focus:border-emerald-500" />
          </div>
          <div>
            <label className="block text-sm text-zinc-500 mb-2">About Me</label>
            <textarea name="about" defaultValue={personalInfo.about} rows={4} className="w-full bg-zinc-800 border border-white/10 rounded-xl p-3 text-white focus:outline-none focus:border-emerald-500" />
          </div>
          <button type="submit" className="w-full py-4 bg-emerald-500 text-zinc-900 font-bold rounded-xl hover:bg-emerald-400 transition-all">Save Changes</button>
        </form>
      </Modal>

      <Modal 
        isOpen={editModal?.type === 'project'} 
        onClose={() => setEditModal(null)} 
        title="Edit Project"
      >
        {editModal?.type === 'project' && editModal?.index !== undefined && (
          <form onSubmit={(e) => handleUpdateProject(e, editModal.index!)} className="space-y-4">
            <div>
              <label className="block text-sm text-zinc-500 mb-2">Project Title</label>
              <input name="title" defaultValue={projects[editModal.index].title} className="w-full bg-zinc-800 border border-white/10 rounded-xl p-3 text-white focus:outline-none focus:border-emerald-500" />
            </div>
            <div>
              <label className="block text-sm text-zinc-500 mb-2">Description</label>
              <textarea name="description" defaultValue={projects[editModal.index].description} rows={3} className="w-full bg-zinc-800 border border-white/10 rounded-xl p-3 text-white focus:outline-none focus:border-emerald-500" />
            </div>
            <div>
              <label className="block text-sm text-zinc-500 mb-2">Tags (comma separated)</label>
              <input name="tags" defaultValue={projects[editModal.index].tags.join(', ')} className="w-full bg-zinc-800 border border-white/10 rounded-xl p-3 text-white focus:outline-none focus:border-emerald-500" />
            </div>
            <div>
              <label className="block text-sm text-zinc-500 mb-2">Image URL</label>
              <input name="image" defaultValue={projects[editModal.index].image} className="w-full bg-zinc-800 border border-white/10 rounded-xl p-3 text-white focus:outline-none focus:border-emerald-500" />
            </div>
            <button type="submit" className="w-full py-4 bg-emerald-500 text-zinc-900 font-bold rounded-xl hover:bg-emerald-400 transition-all">Update Project</button>
          </form>
        )}
      </Modal>

      <Modal 
        isOpen={editModal?.type === 'experience'} 
        onClose={() => setEditModal(null)} 
        title="Edit Experience"
      >
        {editModal?.type === 'experience' && editModal?.index !== undefined && (
          <form onSubmit={(e) => handleUpdateExperience(e, editModal.index!)} className="space-y-4">
            <div>
              <label className="block text-sm text-zinc-500 mb-2">Company Name</label>
              <input name="company" defaultValue={experience[editModal.index].company} className="w-full bg-zinc-800 border border-white/10 rounded-xl p-3 text-white focus:outline-none focus:border-emerald-500" />
            </div>
            <div>
              <label className="block text-sm text-zinc-500 mb-2">Role</label>
              <input name="role" defaultValue={experience[editModal.index].role} className="w-full bg-zinc-800 border border-white/10 rounded-xl p-3 text-white focus:outline-none focus:border-emerald-500" />
            </div>
            <div>
              <label className="block text-sm text-zinc-500 mb-2">Period</label>
              <input name="period" defaultValue={experience[editModal.index].period} className="w-full bg-zinc-800 border border-white/10 rounded-xl p-3 text-white focus:outline-none focus:border-emerald-500" />
            </div>
            <div>
              <label className="block text-sm text-zinc-500 mb-2">Description</label>
              <textarea name="description" defaultValue={experience[editModal.index].description} rows={3} className="w-full bg-zinc-800 border border-white/10 rounded-xl p-3 text-white focus:outline-none focus:border-emerald-500" />
            </div>
            <button type="submit" className="w-full py-4 bg-emerald-500 text-zinc-900 font-bold rounded-xl hover:bg-emerald-400 transition-all">Update Experience</button>
          </form>
        )}
      </Modal>

      <Modal 
        isOpen={editModal?.type === 'skill'} 
        onClose={() => setEditModal(null)} 
        title="Edit Skill Group"
      >
        {editModal?.type === 'skill' && editModal?.index !== undefined && (
          <form onSubmit={(e) => handleUpdateSkillGroup(e, editModal.index!)} className="space-y-4">
            <div>
              <label className="block text-sm text-zinc-500 mb-2">Category Name</label>
              <input name="category" defaultValue={skills[editModal.index].category} className="w-full bg-zinc-800 border border-white/10 rounded-xl p-3 text-white focus:outline-none focus:border-emerald-500" />
            </div>
            <div>
              <label className="block text-sm text-zinc-500 mb-2">Skills (comma separated)</label>
              <textarea name="items" defaultValue={skills[editModal.index].items.join(', ')} rows={3} className="w-full bg-zinc-800 border border-white/10 rounded-xl p-3 text-white focus:outline-none focus:border-emerald-500" />
            </div>
            <button type="submit" className="w-full py-4 bg-emerald-500 text-zinc-900 font-bold rounded-xl hover:bg-emerald-400 transition-all">Update Group</button>
          </form>
        )}
      </Modal>

      <Modal 
        isOpen={editModal?.type === 'reference'} 
        onClose={() => setEditModal(null)} 
        title="Edit Reference"
      >
        {editModal?.type === 'reference' && editModal?.index !== undefined && (
          <form onSubmit={(e) => handleUpdateReference(e, editModal.index!)} className="space-y-4">
            <div>
              <label className="block text-sm text-zinc-500 mb-2">Full Name</label>
              <input name="name" defaultValue={references[editModal.index].name} className="w-full bg-zinc-800 border border-white/10 rounded-xl p-3 text-white focus:outline-none focus:border-emerald-500" />
            </div>
            <div>
              <label className="block text-sm text-zinc-500 mb-2">Position</label>
              <input name="position" defaultValue={references[editModal.index].position} className="w-full bg-zinc-800 border border-white/10 rounded-xl p-3 text-white focus:outline-none focus:border-emerald-500" />
            </div>
            <div>
              <label className="block text-sm text-zinc-500 mb-2">Email</label>
              <input name="email" defaultValue={references[editModal.index].email} className="w-full bg-zinc-800 border border-white/10 rounded-xl p-3 text-white focus:outline-none focus:border-emerald-500" />
            </div>
            <div>
              <label className="block text-sm text-zinc-500 mb-2">Phone</label>
              <input name="phone" defaultValue={references[editModal.index].phone} className="w-full bg-zinc-800 border border-white/10 rounded-xl p-3 text-white focus:outline-none focus:border-emerald-500" />
            </div>
            <button type="submit" className="w-full py-4 bg-emerald-500 text-zinc-900 font-bold rounded-xl hover:bg-emerald-400 transition-all">Update Reference</button>
          </form>
        )}
      </Modal>

      {/* Footer */}
      <footer className="py-12 px-6 border-t border-white/5">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-center gap-8">
          <div className="text-zinc-500 text-sm">
            © {new Date().getFullYear()} {personalInfo.name}. All rights reserved.
          </div>
          <div className="flex items-center gap-6">
            {personalInfo.socials.map((social) => (
              <a key={social.name} href={social.url} className="text-zinc-500 hover:text-white transition-colors">
                <social.icon size={20} />
              </a>
            ))}
          </div>
        </div>
      </footer>
    </div>
  );
}
